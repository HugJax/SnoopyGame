
package menuproto;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JLabel;


public class Button extends JPanel{
    
    private JLabel texture;
    private ImageIcon icon;
    private final String m_texturePath;
    
    public Button(String texturePath) {
        super();
        m_texturePath = texturePath;
        this.setTexture(m_texturePath);
    }
    
    public void setTexture(String texturePath) {
        
        this.removeAll();
        icon    = new ImageIcon(texturePath + ".png");
        texture = new JLabel();
        texture.setIcon(icon);
        this.add(texture);
    }
    
    public String getTexturePath() {
        return m_texturePath;
    }
}
