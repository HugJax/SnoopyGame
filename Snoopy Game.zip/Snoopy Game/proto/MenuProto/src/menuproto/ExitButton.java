
package menuproto;


public class ExitButton {
    
    public ExitButton() {
        
    }
    
}
