
package menuproto;


public class MenuProto {

    public static void main(String[] args) {
        
        Window window = new Window();
        window.setVisible(true);
        
    }
    
}
