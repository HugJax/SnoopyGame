
package menuproto;

import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JFrame;




public class Window extends JFrame implements KeyListener {
    
    private static final int KEY_DOWN   = KeyEvent.VK_DOWN;
    private static final int KEY_UP     = KeyEvent.VK_UP;
    private static final int KEY_LEFT   = KeyEvent.VK_LEFT;
    private static final int KEY_RIGHT  = KeyEvent.VK_RIGHT;
    private static final int KEY_ENTER  = KeyEvent.VK_ENTER;
    
    private int selection;
    
    private Button playButton;
    private Button computerButton;
    private Button loadButton;
    private Button passwordButton;
    private Button scoresButton;
    private Button exitButton;
    ArrayList<Button> arrayButton;
    
    public Window() {
        super();
        selection = 0;
        addKeyListener(this);
        windowProperties();
    }
    
    private void windowProperties() {
        this.setSize(1280, 820);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new GridLayout(6, 1));
        
        playButton      = new Button("textures/bouton jouer");
        computerButton  = new Button("textures/bouton ordinateur");
        loadButton      = new Button("textures/bouton charger partie");
        passwordButton  = new Button("textures/bouton mot de passe");
        scoresButton    = new Button("textures/bouton scores");
        exitButton      = new Button("textures/bouton quitter");
        
        arrayButton = new ArrayList();
        arrayButton.add(playButton);
        arrayButton.add(computerButton);
        arrayButton.add(loadButton);
        arrayButton.add(passwordButton);
        arrayButton.add(scoresButton);
        arrayButton.add(exitButton);
        
        this.add(playButton);
        this.add(computerButton);
        this.add(loadButton);
        this.add(passwordButton);
        this.add(scoresButton);
        this.add(exitButton);
    }

    @Override
    public void keyTyped(KeyEvent event) {
        
    }

    @Override
    public void keyPressed(KeyEvent event) {
        
        Button b = arrayButton.get(selection);
        b.setTexture(b.getTexturePath());
        
        switch(event.getKeyCode()) {
            case KEY_DOWN:
                selection++;
                if (selection > 5) {
                    selection = 0;
                }
                break;
                
            case KEY_UP:
                selection--;
                if (selection < 0) {
                    selection = 5;
                }
                break;
                
            case KEY_ENTER:
                break;
        }
        
        b = arrayButton.get(selection);
        b.setTexture(b.getTexturePath() + " select");
        this.setVisible(true);
        
        System.out.println("selection=" + selection);
    }

    @Override
    public void keyReleased(KeyEvent event) {
        
    }
    
}
