
package snoopy.game.Pages.RegisterScore;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import snoopy.game.MyInterface;
import snoopy.game.Page;
import snoopy.game.Pages.gamepage.Stage;
import snoopy.game.Pages.homepage.HomePage;


public class RegisterScore extends Page{
    
    private String pseudo;
    private final int score;
    private String[][] scoreList;
    private boolean registering;
    private boolean keyTyped;
    private JLabel message;
    
    public RegisterScore(int score) {
        
        this.pseudo = "";
        this.score = score;
        this.registering = false;
        this.keyTyped = true;
        this.scoreList = new String[10][2];
        this.setLayout(new FlowLayout(FlowLayout.CENTER, 1280, 20));
        
        Font font = new Font("BRLNSB.TTF", Font.BOLD, 24);
        Font titleFont = new Font("BRLNSB.TTF", Font.BOLD, 48);
        
        // chargement des scores
        loadScores();
        sortScore();
        
        // SCORE
        JLabel Score = new JLabel("TON SCORE: " + score);
        Score.setFont(titleFont);
        Score.setForeground(Color.yellow);
        Score.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Score);
        
        for(int i = 9; i >= 0; i--) {
            
            JLabel scoreLabel = new JLabel(scoreList[i][0] + " - " + scoreList[i][1]);
            scoreLabel.setFont(font);
            scoreLabel.setForeground(Color.yellow);
            add(scoreLabel);
            
        }
        
        // question: voulez-vous enregistrer votre score ?
        message = new JLabel("Voulez-vous enregistrer votre score ? Y/N");
        message.setFont(titleFont);
        message.setForeground(Color.yellow);
        add(message);
        
    }
    
    private void loadScores() {
        
        String fichier = "scoreboard.txt";
        
        try {
            
            FileReader fr = new FileReader(fichier);
            BufferedReader br = new BufferedReader(fr);
            String str;
            String[] splits;
            
            for(int i = 0; i < 10; i++)
            {
                
                str=br.readLine();
                splits = str.split(";");
                
                scoreList[i][0] = splits[0];
                scoreList[i][1] = splits[1];
                
            }
            
            br.close();
            
        }
        catch(IOException ioe) {
            System.out.println("erreur:"+ioe);
        }
        
    }
    
    private void saveScores() {
        
        System.out.println("sauvegarde");
        
        File file = new File("scoreboard.txt");
        
        try {
            
            FileWriter writer = new FileWriter(file);
            
            // sauvegarde de la tilemap
            for(int i = 0; i < 10; i++) {
                
                writer.write(scoreList[i][0] + ";" + scoreList[i][1] + "\n");
                
            }
            
            writer.close();
            
        } catch(IOException ex) {
            Logger.getLogger(Stage.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private void updatePseudo() {
        
        message.setText("PSEUDO: " + pseudo);
        repaint();
        
    }

    private void sortScore() {
        
        for(int i = 0; i < 8; i++) {
            
            for(int j = 9; j > i + 1; j--) {
                
                if(Integer.parseInt(scoreList[j][1]) < Integer.parseInt(scoreList[i][1])) {
                    
                    String[] temp = scoreList[j];
                    scoreList[j] = scoreList[i];
                    scoreList[i] = temp;
                    System.out.println("insert");
                }
                
            }
            
        }
        
    }
    
    private void insertScore() {
        
        if(Integer.parseInt(scoreList[0][1]) < score) {

            scoreList[0][0] = pseudo;
            scoreList[0][1] = Integer.toString(score);
            sortScore();
            saveScores();

        }

        MyInterface.window.setPage(new HomePage());
        
    }
    
    @Override
    public void clear() {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
        if(registering == false) {
            
            switch(e.getKeyCode()) {

                case KeyEvent.VK_Y:
                    registering = true;
                    updatePseudo();
                    break;

                case KeyEvent.VK_N:
                    registering = true;
                    MyInterface.window.setPage(new HomePage());
                    break;

            }
            
        }
        else {
            
            if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
            
                keyTyped = false;
                pseudo = pseudo.substring(0, (pseudo.length() > 0) ? pseudo.length() - 1 : 0);
                updatePseudo();
            
            }
            if(e.getKeyCode() == KeyEvent.VK_ENTER) {
                
                insertScore();
                
            }
        }
        
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
        
        if(keyTyped == true) {
            
            if(registering == true) {

                pseudo = pseudo + e.getKeyChar();
                updatePseudo();

            }
            
        }
        else {
            
            keyTyped = true;
            
        }
        
    }
    
}
