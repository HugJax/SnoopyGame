# SnoopyGame

Versionning pour la création du Projet "La revanche de Snoopy"

Pour chaque nouvelle partie, créez une nouvelle branche qui ne sera ajoutée que lorsque cette partie sera terminée et validée.
Lorsque vous ajoutez du nouveau code, faîtes le dans la branche dédiée et ajoutez une description des modifications.

On ajoutera également les fichiers visuels dans la branche principale ainsi que les comptes-rendus.
