/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snoopy.game;


/**
 *
 * @author 931701772
 */
public class MatrixMaker {
    
    private int [][] matrix;
    private String [] row;
    
    public MatrixMaker( String [] row){
        this.row=row;
        matrix=new int[10][20];
    
    }
    
    public int [][] create(){
        
                
  {
    int i=0;
    int j=0;
       
        for (i=0;i<10;i++)
        {
            
            
                System.out.println(" loading"+ row[i]) ;
                for (j=0;j<10;j++)
                {
                 System.out.println(row[i].charAt(j)) ;
           matrix[i][j]= (row[i].charAt(j)-48);   
            
            System.out.println(matrix[i][j]) ;
                }
  }
  }
  return matrix;
    }
    
}
