
package snoopy.game;


public interface MyInterface {
    
    public static Window window = new Window();
    
    
}
