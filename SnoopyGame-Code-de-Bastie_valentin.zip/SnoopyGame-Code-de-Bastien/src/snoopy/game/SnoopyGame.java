
package snoopy.game;

import snoopy.game.Pages.gamepage.GamePage;
import snoopy.game.Pages.homepage.HomePage;


public class SnoopyGame {

    public static void main(String[] args) {
      String file1 = "Map.txt";
      FileReaderProject reader1 = new FileReaderProject(file1);
      String [] row = reader1.getinput();
      System.out.println("loading map");
      MatrixMaker maker=new MatrixMaker(row);
      int [][] matrix = maker.create();
      
     
    MyInterface.window.setPage(new GamePage(0,matrix));
     //MyInterface.sauvegardeMap();
    
        
        
    }
    
}

