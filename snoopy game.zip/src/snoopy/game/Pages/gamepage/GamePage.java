
package snoopy.game.Pages.gamepage;

import java.awt.event.KeyEvent;
import snoopy.game.Page;


public class GamePage extends Page {
    
    private Stage stage;
    
    public GamePage(int idxStage) {
        
        super();
        this.stage = new Stage();
        this.add(this.stage);
        //this.setStage("text");
        
    }
    
    public void setStage(String stagePath) {
        
        this.stage = new Stage();
        this.remove(this.stage);
        this.add(this.stage);
        
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
        switch(e.getKeyCode()) {
            
            case KeyEvent.VK_UP:
                this.stage.moveSnoopy(Movement.UP);
                break;
                
            case KeyEvent.VK_DOWN:
                this.stage.moveSnoopy(Movement.DOWN);
                break;
                
            case KeyEvent.VK_LEFT:
                this.stage.moveSnoopy(Movement.LEFT);
                break;
                
            case KeyEvent.VK_RIGHT:
                this.stage.moveSnoopy(Movement.RIGHT);
                break;
                
            case KeyEvent.VK_A:
                break;
                
            case KeyEvent.VK_ESCAPE:
                break;
            
        }
        
        // actualise la texture
        validate();
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
    
}
