
package snoopy.game.Pages.gamepage;

import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import snoopy.game.Page;


public class GamePage extends Page {
    
    private Stage stage;
    
    public GamePage(int idxStage) throws IOException {
        
        super();
        this.stage = new Stage(1000, 500);
        this.add(this.stage);
        
        // ajout de l'interface
        JLabel interface1 = new JLabel();
        JLabel interface2 = new JLabel();
        interface1.setBounds(0, 500, 1270, 220);
        interface2.setBounds(1000, 0, 270, 500);
        
        BufferedImage img1 = ImageIO.read(new File("textures/interface1.jpg"));
        BufferedImage img2 = ImageIO.read(new File("textures/interface2.jpg"));
        Image dimg1 = img1.getScaledInstance(interface1.getWidth(), interface1.getHeight(), Image.SCALE_SMOOTH);
        Image dimg2 = img2.getScaledInstance(interface2.getWidth(), interface2.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon icon1 = new ImageIcon(dimg1);
        ImageIcon icon2 = new ImageIcon(dimg2);
        
        interface1.setIcon(icon1);
        interface2.setIcon(icon2);
        add(interface1);
        add(interface2);
        
    }
    
    public void setStage(String stagePath) {
        
        this.stage = new Stage(1000, 500);
        this.remove(this.stage);
        this.add(this.stage);
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
        try {
            switch(e.getKeyCode()) {
                
                case KeyEvent.VK_UP:
                    this.stage.moveSnoopy(Movement.UP);
                    break;
                    
                case KeyEvent.VK_DOWN:
                    this.stage.moveSnoopy(Movement.DOWN);
                    break;
                    
                case KeyEvent.VK_LEFT:
                    this.stage.moveSnoopy(Movement.LEFT);
                    break;
                    
                case KeyEvent.VK_RIGHT:
                    this.stage.moveSnoopy(Movement.RIGHT);
                    break;
                    
                case KeyEvent.VK_A:
                    break;
                    
                case KeyEvent.VK_ESCAPE:
                    break;
                    
            }
            
            // actualise la texture
            validate();
        } catch (InterruptedException ex) {
            Logger.getLogger(GamePage.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

}
