
package snoopy.game.Pages.gamepage;

import java.awt.Image;
import java.text.DecimalFormat;


public class Snoopy {
    
    private int posX;
    private int posY;
    private int destX;
    private int destY;
    private final int movementSpeed;
    private boolean isMoving;
    
    private final Image img;
    
    public Snoopy(int x, int y, Image img) {
        
        this.posX = x;
        this.posY = y;
        this.destX = (int) this.posX;
        this.destY = (int) this.posY;
        this.movementSpeed = 1;
        this.isMoving = false;
        this.img = img;
        
    }
    
    public double getPosX() {
        
        return this.posX;
        
    }
    
    public double getPosY() {
        
        return this.posY;
        
    }
    
    public Image getImage() {
        
        return this.img;
        
    }
    
    public void move(int movement) {
        
        isMoving = true;
        
        switch(movement) {
            
            case Movement.UP:
                posY--;
                //destY = (int) (posY - 1);
                break;
                
            case Movement.DOWN:
                posY++;
                //destY = (int) (posY + 1);
                break;
                
            case Movement.RIGHT:
                posX++;
                //destX = (int) (posX + 1);
                break;
                
            case Movement.LEFT:
                posX--;
                //destX = (int) (posX - 1);
                break;
                
            default:
                isMoving = false;
                break;
            
        }
        /*
        while((posX != destX) && (posY != destY)) {
            
            if(posX < destX) {
                posX = posX + movementSpeed;
                if(posX > destX) {
                    posX = destX;
                }
            }
            
            if(posX > destX) {
                posX = posX - movementSpeed;
                if(posX < destX) {
                    posX = destX;
                }
            }
            
            if(posY < destY) {
                posY = posY + movementSpeed;
                if(posY > destY) {
                    posY = destY;
                }
            }
            
            if(posY > destY) {
                posY = posY - movementSpeed;
                if(posY < destY) {
                    posY = destY;
                }
            }
            
            
        }
        */
        System.out.println("PosX=" + posX + "  posY=" + posY);
        
    }
}
