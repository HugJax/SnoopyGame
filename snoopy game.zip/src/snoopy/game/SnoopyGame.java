
package snoopy.game;

import snoopy.game.Pages.homepage.HomePage;


public class SnoopyGame {

    public static void main(String[] args) {
        
        MyInterface.window.setPage(new HomePage());
        
    }
    
}
